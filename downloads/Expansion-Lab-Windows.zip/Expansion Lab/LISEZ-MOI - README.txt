Expansion Lab – version hors-ligne / offline version
====================================================

FR : Double-cliquez sur « Expansion Lab.html » pour lancer l'application
     dans votre navigateur (Edge, Chrome ou Firefox). Aucune installation,
     fonctionne sans internet. Site : https://guizmoh.github.io/expansion-lab/

EN : Double-click "Expansion Lab.html" to open the app in your browser
     (Edge, Chrome or Firefox). No install, works offline.
     Website: https://guizmoh.github.io/expansion-lab/en/

Cet outil vous a été utile ? / Was this tool useful?
https://ko-fi.com/omnipotard

Open source (MIT) – https://github.com/Guizmoh/expansion-lab
